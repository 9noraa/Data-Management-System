﻿/* Name: Aaron Cohen
 * FSUID: ajc17d
 * Assignment: A4.0
 */

//App javascript file that interacts with the html 
//Angular framework

var app = angular.module("MusicMovies", ["ngRoute"]);
app.controller('mainCtrl', function ($scope, $http) {
    //Added a review counter
    $scope.nextMedia = 5;
    $scope.nextReview = 5;
    
    $http({
        method: 'GET',
        url: 'api/Media/Get'
    }).then(function success(response) {
        $scope.medias = response.data;
    }, function failure() {

    });

    //Shows the reviews for the media at id 1
    $http({
        method: 'GET',
        url:'api/Media/GetById/1'
    }).then(function success(response) {
        $scope.selectedMedia = response.data;
    }, function failure() {

    });

    

    $scope.selectMedia = function (media) {
        $scope.addingMedia = false;
        $scope.selectedReview = undefined;
        $scope.selectedMedia = media;
    }

    //Array of objects that act as the review
    //Holds a user name, review and the rating
    $scope.reviews = [{ id: 0, MediaId: 1, userName: 'Drakefan1', review: 'My favorite song on the album', rating: '10' },
        { id: 1, MediaId: 1, userName: 'musicfan101', review: 'An amazing song', rating: '9' }, { id: 2, MediaId: 2, userName: 'musicfan101', review: 'Another amazing song', rating: '9' },
        { id: 3, MediaId: 3, userName: 'TransfromersCritic', review: 'My favorite movie in the series', rating: '7' },
        { id: 4, MediaId: 4, userName: 'Comicbookfan99', review: 'Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos', rating: '8' }];

    $scope.selectReview = function (rl) {
        $scope.addingReview = false;
        $scope.selectedReview = rl;
    }

    $scope.showNewReview = function () {
        $scope.addingReview = true;
        $scope.selectedReview = new Object();
    }

    //Add review function 
    $scope.addReview = function () {
        $scope.selectedReview.id = $scope.nextReview;
        $scope.nextReview += 1;
        $scope.selectedReview.MediaId = $scope.selectedMedia.id;
        $scope.reviews.push($scope.selectedReview);
        $scope.selectedReview = undefined;
        $scope.addingReview = false;
    }

    $scope.cancelAddReview = function () {
        $scope.selectedReview = undefined;
        $scope.addingReview = false;
    }

    $scope.showNewMedia = function () {
        $scope.selectedMedia = undefined;
        $scope.addingMedia = true;
    }
    $scope.addMedia = function () {
        $scope.selectedMedia.id = $scope.nextMedia;
        $scope.nextMedia += 1;
        
        //Post method sends the data from the html front end to the C# program and the static class
        $http({
            method: 'POST',
            url: 'api/Media/AddOrUpdate',
            data: $scope.selectedMedia
        }).then(function success(response) {
            $scope.medias.push(response.data);
        }, function failure() {

        });

        $scope.selectedMedia = undefined;
        $scope.addingMedia = false;
    }

    $scope.cancelAddMedia = function () {
        $scope.selectedMedia = undefined;
        $scope.addingMedia = false;
    }

    //Remove functions
    $scope.removeMedia = function (id) {
        var indexToDelete = -1;
        for (i = 0; i < $scope.medias.length; i++) {
            if ($scope.medias[i].id === id) {
                indexToDelete = i;
                break;
            }
        }
        if (indexToDelete >= 0) {
            $scope.medias.splice(indexToDelete, 1);
        }

    }

    $scope.removeReview = function (id) {
        var indexToDelete = -1;
        for (i = 0; i < $scope.reviews.length; i++) {
            if ($scope.reviews[i].id === id) {
                indexToDelete = i;
                break;
            }
        }
        if (indexToDelete >= 0) {
            $scope.reviews.splice(indexToDelete, 1);
        }

        if ($scope.selectedReview.id == id) {
            $scope.selectedReview = undefined;
        }
    }
});
