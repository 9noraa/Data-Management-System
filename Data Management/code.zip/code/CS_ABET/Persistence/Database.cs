﻿/* Name: Aaron Cohen
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ABET.Persistence
{
    //Database class that holds the media class list
    public static class Database
    {
        //List that displays each song or movie
        public static List<Media> Medias = new List<Media> { 
            new Media{Id = 1, Title = "One Dance", creator = "Drake", genre = "Hip Hop", runTime = 150},
            new Media{Id = 2, Title = "Nice For What", creator = "Drake", genre = "Hip Hop", runTime = 200},
            new Media{Id = 3, Title = "Transformers 2", creator = "Michael Bay", genre = "Action", runTime = 3800},
            new Media{Id = 4, Title = "Avengers: Infinity War", creator = "Joe Russo", genre = "Action", runTime = 3800}
        };
    }

    //Media class that has variables for titles, artist, genre and the run time of the media
    public partial class Media
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string creator { get; set; }
        public string genre { get; set; }
        public int runTime { get; set; }

    }
}