﻿/* Name: Aaron Cohen
 */

using CS_ABET.Persistence;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace CS_ABET.Controllers.Api
{
    //Controller class that gets the url routes and runs functions
    [RoutePrefix("api/Media")]
    public class SemesterController : ApiController
    {
        [HttpGet]
        [Route("Get")]
        public async Task<IHttpActionResult> Get()
        {
            return Ok(Database.Medias);
        }

        [HttpGet]
        [Route("GetById/{id}")]
        public async Task<IHttpActionResult> GetById(int id)
        {
            return Ok(Database.Medias.FirstOrDefault(s => s.Id == id));
        }

        [HttpPost]
        [Route("AddOrUpdate")]
        public async Task<IHttpActionResult> AddOrUpdate([FromBody] Media media)
        {
            if(media != null)
            {
                Database.Medias.Add(media);
            }

            return Ok(media);
        }
    }
}